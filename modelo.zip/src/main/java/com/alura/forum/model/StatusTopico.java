package com.alura.forum.model;

public enum StatusTopico {

	SIN_RESPUESTA, NO_SOLUCIONADO, SOLUCIONADO, CERRADO;

}
